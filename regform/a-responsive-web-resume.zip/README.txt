A Pen created at CodePen.io. You can find this one at https://codepen.io/dudleystorey/pen/NqaYxy.

 A responsive variation of an [older example by Chris Coyier](https://css-tricks.com/one-page-resume-site/). [Complete article](http://thenewcode.com/553/Build-A-Responsive-Web-Resume)